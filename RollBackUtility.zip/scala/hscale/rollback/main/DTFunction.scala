package hscale.rollback.main
import hscale.rollback.ApplicationData._
import org.apache.hadoop.fs.{ FileSystem, Path }

class DTfunction(RollbackDetail:RollbackApplicationDetails) {
	def dt1function(){
	 
	  
		for (counter <- 0 until RollbackDetail.AllProcessedDT1MappingId.length) {
		  println(s"RollbackDetail.AllDependentDT1MappingId is $RollbackDetail.AllDependentDT1MappingId")
			if (RollbackDetail.AllDependentDT1MappingId.contains(RollbackDetail.AllProcessedDT1MappingId(counter)) == true) {
				var DT1Entity = RollbackDetail.AllProcessedDT1EntityName(counter).toUpperCase
						var DT1MappingId = RollbackDetail.AllProcessedDT1MappingId(counter)
						var DT1Path = new Path(RollbackDetail.fileConf.getString("hscalePath.hscale_base_path")+RollbackDetail.fileConf.getString("hscalePath.dt1")+RollbackDetail.AllProcessedDT1ModelName(counter)+"/"+DT1Entity+"/"+DT1MappingId)
					
						HDFSDeleteFunction.deleteFromHDFS(RollbackDetail.spark,RollbackDetail.fs, DT1Path, new Path(RollbackDetail.fileConf.getString("backupPath.temp")), RollbackDetail.BatchId, "DT",RollbackDetail.CurrentAppId,RollbackDetail)              
						DAOFunction.deleteTable("DT_MAPPING_AUDIT",RollbackDetail.AllProcessedDT1JobId(counter),RollbackDetail.getHealthPlan(),DT1Entity)
						DAOFunction.deleteTable("DT_MAPPING_EXEC_STATUS",RollbackDetail.AllProcessedDT1JobId(counter),RollbackDetail.getHealthPlan(),DT1Entity)
						DAOFunction.deleteTable("JOB_HISTORY",RollbackDetail.AllProcessedDT1JobId(counter),RollbackDetail.getHealthPlan(),DT1Entity)
			}

		}
	}
		def dt2function(){
		
			for (counter <- 0 until RollbackDetail.AllProcessedDT2MappingId.length) {
				if (RollbackDetail.AllDependentDT2MappingId.contains(RollbackDetail.AllProcessedDT2MappingId(counter)) == true) {
					var MappingId = RollbackDetail.AllProcessedDT2MappingId(counter)
							var DT2Entity = RollbackDetail.AllProcessedDT2EntityName(counter).toUpperCase
							var DT2ModelName = RollbackDetail.AllProcessedDT2ModelName(counter)
							
					var DT2Path = new Path(RollbackDetail.fileConf.getString("hscalePath.hscale_base_path")+RollbackDetail.fileConf.getString("hscalePath.dt2")+DT2ModelName+"/"+DT2Entity+"/"+MappingId)
				

							HDFSDeleteFunction.deleteFromHDFS(RollbackDetail.spark,RollbackDetail.fs, DT2Path, new Path(RollbackDetail.fileConf.getString("backupPath.temp")), RollbackDetail.BatchId, "DT",RollbackDetail.CurrentAppId,RollbackDetail)
						DAOFunction.deleteTable("DT_MAPPING_AUDIT",RollbackDetail.AllProcessedDT2JobId(counter),RollbackDetail.getHealthPlan(),DT2Entity)
						DAOFunction.deleteTable("DT_MAPPING_EXEC_STATUS",RollbackDetail.AllProcessedDT2JobId(counter),RollbackDetail.getHealthPlan(),DT2Entity)
						DAOFunction.deleteTable("JOB_HISTORY",RollbackDetail.AllProcessedDT2JobId(counter),RollbackDetail.getHealthPlan(),DT2Entity)

				} 
			}
		  
		}

	
}