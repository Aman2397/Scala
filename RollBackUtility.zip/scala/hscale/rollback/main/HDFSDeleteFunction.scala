package hscale.rollback.main
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.hadoop.conf.Configuration
import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.catalyst.expressions.Concat
import org.apache.spark.sql.DataFrame
import com.typesafe.config.{Config, ConfigFactory}
import hscale.rollback.ApplicationData
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.functions._
import hscale.rollback.ApplicationData.RollbackApplicationDetails
object HDFSDeleteFunction {
var Index: Int = 0;
var subpart: String = null;
var InterPath: Path = null;
var Path_To_Persist: Path = null;
var Original_Data: DataFrame = null;
var data_to_delete: DataFrame = null;
var Data_To_Store: DataFrame = null;


 


def deleteFromHDFS(spark: SparkSession, fs: FileSystem, FinalPath: Path, Temporary: Path, BATCH_ID: Int, stage: String,CurrentAppId:String,RollbackDetail:RollbackApplicationDetails){
	stage match {
	case "DQ1" | "DQ2" => DeleteFromDQ(spark,fs,FinalPath,Temporary,BATCH_ID,stage,CurrentAppId,RollbackDetail)
	case "RAW" =>DeleteFromInterim(spark,fs,FinalPath,Temporary,BATCH_ID,stage,CurrentAppId,RollbackDetail)
	case "DT" =>DeleteFromDT(spark,fs,FinalPath,Temporary,BATCH_ID,stage,CurrentAppId,RollbackDetail)
	case _=> "Unknown Stage"
	}
}

def DeleteFromInterim(spark: SparkSession, fs: FileSystem, FinalPath: Path, Temporary: Path, BATCH_ID: Int, stage: String,CurrentAppId:String,RollbackDetail:RollbackApplicationDetails){
	println("Hi from Deleteinterim")
	if (fs.exists(FinalPath)){
	  
		Original_Data = spark.read.parquet(FinalPath.toString())

				val Time = Original_Data.filter(s"ETL_BATCH_ID=$BATCH_ID").select("FILELOADDATE").distinct().collect.map(x => x.toString.replace("[", "").replace("]", ""))
				if (Time.length > 0) {
					val FILELOADDATE = Time(0)
							Original_Data = spark.read.parquet(FinalPath.toString())
							Index = FinalPath.toString().indexOf("<String>")
							subpart = FinalPath.toString().substring(Index + 9, FinalPath.toString().length)
							InterPath = new Path(subpart)
							Path_To_Persist = new Path(RollbackDetail.fileConf.getString("backupPath.backup")+"/"+CurrentAppId+"/"+InterPath)              
							Original_Data.write.parquet(Path_To_Persist.toString())
							data_to_delete = Original_Data.filter(s"FILELOADDATE='$FILELOADDATE'");
					Data_To_Store = performJoin(Original_Data,data_to_delete,"FILELOADDATE")
							if (Data_To_Store.count == 0) fs.delete(FinalPath, true)
							else
								dataMovement(spark, fs, Data_To_Store, Temporary, FinalPath: Path)

				}


	}  else println(s"$FinalPath Does Not Exist")
	println("Bye from Deleteinterim")
}
def DeleteFromDQ(spark: SparkSession, fs: FileSystem, FinalPath: Path, Temporary: Path, BATCH_ID: Int, stage: String,CurrentAppId:String,RollbackDetail:RollbackApplicationDetails){
	println("Hi from Deletedq")
	if (fs.exists(FinalPath)) {
		Original_Data = spark.read.parquet(FinalPath.toString())
				var Time = Array[String]();
		if (stage.equals("DQ1"))
			Time = Original_Data.filter(s"ETL_BATCH_ID=$BATCH_ID").select("FILELOADDATE_YEAR", "FILELOADDATE_MONTH", "DQDS_PROCESS_DATETIME").distinct().collect.map(x => x.toString.replace("[", "").replace("]", ""))
			if (stage.equals("DQ2"))
				Time = Original_Data.filter(s"LoadProcessId=$BATCH_ID").select("FILELOADDATE_YEAR", "FILELOADDATE_MONTH", "DQDS_PROCESS_DATETIME").distinct().collect.map(x => x.toString.replace("[", "").replace("]", ""))
				if (Time.length > 0) {
					val RUNDATE = Time(0).toString().split(",")
							val year = RUNDATE(0)
							val month = RUNDATE(1)
							val DQDS_PROCESS_DATETIME = RUNDATE(2);
					val path1 = new Path(s"${FinalPath.toString()}/FILELOADDATE_YEAR=$year/FILELOADDATE_MONTH=$month")
							println("stage1")
							val DestinedPath = path1;
					Original_Data = spark.read.parquet(DestinedPath.toString())
							Index = path1.toString().indexOf("dq")
							subpart = FinalPath.toString().substring(Index + 3, FinalPath.toString().length)
							InterPath = new Path(subpart)
							Path_To_Persist = new Path(RollbackDetail.fileConf.getString("backupPath.backup")+"/"+CurrentAppId+"/DQ/"+InterPath)

							Original_Data.write.parquet(Path_To_Persist.toString())
							data_to_delete = Original_Data.filter(s"DQDS_PROCESS_DATETIME='$DQDS_PROCESS_DATETIME'");
					    Data_To_Store = performJoin(Original_Data,data_to_delete,"DQDS_PROCESS_DATETIME")
							if (Data_To_Store.count == 0) fs.delete(DestinedPath, true)
							else
								dataMovement(spark, fs, Data_To_Store, Temporary, DestinedPath)   
				}

	}  else println(s"$FinalPath Does Not Exist")

println("Bye from Deletedq")

}

def DeleteFromDT(spark: SparkSession, fs: FileSystem, FinalPath: Path, Temporary: Path, BATCH_ID: Int, stage: String,CurrentAppId:String,RollbackDetail:RollbackApplicationDetails){
	println("Hi from dtdelete") 
	val fileconf1 = ConfigFactory.load("file.conf")
	if (fs.exists(FinalPath)) {
		Original_Data = spark.read.parquet(FinalPath.toString())
				var Time = Original_Data.filter(s"LoadProcessId=$BATCH_ID").select("DT_JOB_RUN_DATE").distinct().collect.map(x => x.toString.replace("[", "").replace("]", ""))
				if (Time.length > 0) {
					val DT_JOB_RUN_DATE = Time(0)
							data_to_delete = Original_Data.filter(s"DT_JOB_RUN_DATE='$DT_JOB_RUN_DATE'")
							Data_To_Store = (Original_Data.join(data_to_delete, Original_Data.col("DT_JOB_RUN_DATE").equalTo(data_to_delete.col("DT_JOB_RUN_DATE")), "LEFTANTI"))
							Index = FinalPath.toString().indexOf("dt")
							subpart = FinalPath.toString().substring(Index + 3, FinalPath.toString().length)
							InterPath = new Path(subpart)
							Path_To_Persist = new Path(RollbackDetail.fileConf.getString("backupPath.backup")+"/"+CurrentAppId+"/"+stage+"/"+InterPath)
							println(s"Path_To_Persist:$Path_To_Persist")
							Original_Data.write.parquet(Path_To_Persist.toString())
							dataMovement(spark, fs, Data_To_Store, Temporary, FinalPath)
				}

	}
	else println(s"$FinalPath Does Not Exist")
		println("bye from dtdelete") 
}


def DeleteDR(spark: SparkSession, fs: FileSystem, FinalPath: Path, Temporary: Path, LOADPROCESSID: Int, EntityName: String, UniqueIdentifier: String,CurrentAppId:String,RollbackDetail:RollbackApplicationDetails){
	println("Hi from dr")
	if (fs.exists(FinalPath)) {
		val DRSTATUS1 = new Path(s"${FinalPath.toString()}/DR_STATUS=1")    //dr status path1
				val DRSTATUS0 = new Path(s"${FinalPath.toString()}/DR_STATUS=0")    //dr status path0
				val RECON = spark.read.parquet(s"${DRSTATUS1.toString()}").select("RECON_JOB_RUN_DATE").filter(s"LOADPROCESSID=$LOADPROCESSID").distinct().collect
				val DR1DATA = spark.read.parquet(s"${DRSTATUS1.toString()}")        //read dr1 data
				val DR0DATA = spark.read.parquet(s"${DRSTATUS0.toString()}")        //read dr0 data
				var DR_TO_STORE_FROM0: DataFrame = null;
				var Path_To_Persist1: Path = null;
				var Path_To_Persist0: Path = null;
				Index = FinalPath.toString().indexOf("dr")

						subpart = FinalPath.toString().substring(Index + 3, FinalPath.toString().length)
						InterPath = new Path(subpart)

						Path_To_Persist1 = new Path(RollbackDetail.fileConf.getString("backupPath.backup")+"/"+CurrentAppId+"/DR/"+InterPath+"/DR_STATUS=1")
						Path_To_Persist0 = new Path(RollbackDetail.fileConf.getString("backupPath.backup")+"/"+CurrentAppId+"/DR/"+InterPath+"/DR_STATUS=0")

						if(RECON.length>0)
						{ DR1DATA.write.parquet(Path_To_Persist1.toString())
							DR0DATA.write.parquet(Path_To_Persist0.toString())
							val RECON_JOB_RUN_DATE=RECON(0).getTimestamp(0)
							val DATA_TO_DELETE_DR1=spark.read.parquet(s"${DRSTATUS1.toString()}").filter(s"RECON_JOB_RUN_DATE='$RECON_JOB_RUN_DATE'")

							var Data_To_Store_DR1=(DR1DATA.join(DATA_TO_DELETE_DR1,DR1DATA.col("RECON_JOB_RUN_DATE").equalTo(DATA_TO_DELETE_DR1.col("RECON_JOB_RUN_DATE")),"LEFTANTI"))
							if(Data_To_Store_DR1.count==0){
								fs.delete(DRSTATUS1,true)
							}
							else{
								Data_To_Store_DR1.write.parquet(Temporary.toString())
								fs.delete(DRSTATUS1,true)

								Data_To_Store_DR1=spark.read.parquet(s"${Temporary.toString()}")
								Data_To_Store_DR1.write.parquet(DRSTATUS1.toString())
								fs.delete(Temporary,true)


							}          



						val ModifyDate=spark.read.parquet(s"${DRSTATUS0.toString()}").filter(s"RECON_MODIFIED_DATETIME>'$RECON_JOB_RUN_DATE'").select("RECON_MODIFIED_DATETIME").distinct().collect

								if(ModifyDate.length>0)
								{val RECON_MODIFIED_DATETIME=ModifyDate(0).getTimestamp(0)
								val DR0_RequiredData_delete=spark.read.parquet(s"${DRSTATUS0.toString()}").filter(s"RECON_MODIFIED_DATETIME>'$RECON_JOB_RUN_DATE'")
								val DR0_FilteredRequiredData_delete=spark.read.parquet(s"${DRSTATUS0.toString()}").filter(s"RECON_MODIFIED_DATETIME>'$RECON_JOB_RUN_DATE' AND RECON_JOB_RUN_DATE<>'$RECON_JOB_RUN_DATE'")
								DR0_FilteredRequiredData_delete.createOrReplaceTempView("view")
								if(EntityName.equalsIgnoreCase("MemberAddress"))
									DR_TO_STORE_FROM0=spark.sql("select *,ROW_NUMBER() OVER (PARTITION BY '$UniqueIdentifier' ORDER BY EntityLoadDate Desc) as rownumber FROM view").filter("rownumber=1")
									else
										DR_TO_STORE_FROM0=DR0_RequiredData_delete
										DR_TO_STORE_FROM0.drop("DR_STATUS","RECON_MODIFIED_DATETIME","RECON_EFFECTIVE_TO_DATE","rownumber").createOrReplaceTempView("IntermediateDR")
										var DR1_TO_STORE=spark.sql("select *,cast(1 as int) as DR_STATUS,cast(null as timestamp) as RECON_MODIFIED_DATETIME,cast(null as timestamp) as RECON_EFFECTIVE_TO_DATE from IntermediateDR")
										if(fs.exists(DRSTATUS1)){                                                                             
											DR1_TO_STORE.write.mode("append").parquet(DRSTATUS1.toString())
										}
										else{
											DR1_TO_STORE.write.parquet(DRSTATUS1.toString())
										}
								var Data_To_Store_DR0=(DR0DATA.join(DR0_RequiredData_delete,DR0DATA.col("RECON_MODIFIED_DATETIME").equalTo(DR0_RequiredData_delete.col("RECON_MODIFIED_DATETIME")),"LEFTANTI"))
										if (Data_To_Store_DR0.count == 0) fs.delete(DRSTATUS0, true)
										else{
											Data_To_Store_DR0.write.parquet(Temporary.toString())
											fs.delete(DRSTATUS0,true)

											Data_To_Store_DR0=spark.read.parquet(s"${Temporary.toString()}")
											Data_To_Store_DR0.write.parquet(DRSTATUS0.toString())
											fs.delete(Temporary,true)

										}
								}}


	} else {
		println("PATH DOES NOT EXIST")
	}  
}



def dataMovement(spark: SparkSession, fs: FileSystem, Data_To_Store: DataFrame, Temporary: Path, FinalPath: Path) {
	Data_To_Store.write.parquet(Temporary.toString())
	fs.delete(FinalPath, true)
	fs.delete(FinalPath, true)
	val Store = spark.read.parquet(Temporary.toString())
	Store.write.parquet(FinalPath.toString())
	fs.delete(Temporary, true)
	fs.delete(Temporary, true)
}  
def performJoin(Original_Data: DataFrame, data_to_delete: DataFrame,column:String):DataFrame= {
		val Resultant_DataFrame = (Original_Data.join(data_to_delete, Original_Data.col(s"$column").equalTo(data_to_delete.col(s"$column")), "LEFTANTI"))
				Resultant_DataFrame


}
}