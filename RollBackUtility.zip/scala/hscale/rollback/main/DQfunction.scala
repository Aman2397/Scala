package hscale.rollback.main

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._
import org.apache.spark.SparkContext._
import hscale.rollback.ApplicationData._
import org.apache.log4j._
import com.typesafe.config._
import org.apache.hadoop.fs.{ FileSystem, Path }
import org.apache.spark.sql.catalyst.expressions.Concat
class DQfunction(RollbackDetail:RollbackApplicationDetails){
 val applicationConf = ConfigFactory.load("application.properties")
 val dbConf = ConfigFactory.load("db.properties")
 val database=dbConf.getString("db.database")
	def Dq1Function(){
		
		
		for (counter <- 0 until RollbackDetail.ProcessedEntities.length) {
			if (RollbackDetail.DependentEntities.contains(RollbackDetail.ProcessedEntities(counter)) == true) {
				var InterimPath = RollbackDetail.ProcessedEntitiesPath(counter)
					
						var Entity = RollbackDetail.ProcessedEntities(counter).toString().toUpperCase

						var DQPath: Path = new Path(RollbackDetail.fileConf.getString("hscalePath.hscale_base_path")+RollbackDetail.fileConf.getString("hscalePath.dq1")+RollbackDetail.getHealthPlan()+"/"+RollbackDetail.applicationConf.getString("modelname.sourcemodel")+"/"+RollbackDetail.getHealthPlan()+"/"+Entity)
     
						var RAWPath = new Path(InterimPath.substring(0, InterimPath.indexOf("_RAW") + 15));
					
						HDFSDeleteFunction.deleteFromHDFS(RollbackDetail.spark,RollbackDetail.fs, RAWPath, new Path(RollbackDetail.fileConf.getString("backupPath.temp")), RollbackDetail.BatchId, "RAW",RollbackDetail.CurrentAppId,RollbackDetail)
						HDFSDeleteFunction.deleteFromHDFS(RollbackDetail.spark,RollbackDetail.fs, DQPath,new Path(RollbackDetail.fileConf.getString("backupPath.temp")), RollbackDetail.BatchId, "DQ1",RollbackDetail.CurrentAppId,RollbackDetail)
						DAOFunction.deleteTable("BATCH_STATUS_DETAILS",RollbackDetail.ProcessedDQ1JobId(0),RollbackDetail.getHealthPlan(),Entity)
					  DAOFunction.deleteTable("JOB_HISTORY",RollbackDetail.ProcessedDQ1JobId(0),RollbackDetail.getHealthPlan(),"NA")
						
			
			}
		}
		
	}

	def Dq2Function(){
	 
		for (counter <- 0 until RollbackDetail.AllProcessedDT1MappingId.length) {
			if (RollbackDetail.AllDependentDT1MappingId.contains(RollbackDetail.AllProcessedDT1MappingId(counter)) == true) {
				var DT1Entity = RollbackDetail.AllProcessedDT1EntityName(counter).toUpperCase
						var DQ2Path = new Path(RollbackDetail.fileConf.getString("hscalePath.hscale_base_path")+RollbackDetail.fileConf.getString("hscalePath.dq2")+RollbackDetail.AllProcessedDT1ModelName(counter)+"/"+DT1Entity)
						
						HDFSDeleteFunction.deleteFromHDFS(RollbackDetail.spark,RollbackDetail.fs, DQ2Path, new Path(RollbackDetail.fileConf.getString("backupPath.temp")), RollbackDetail.BatchId, "DQ2",RollbackDetail.CurrentAppId,RollbackDetail)
						DAOFunction.deleteTable("BATCH_STATUS_DETAILS",RollbackDetail.ProcessedDQ2JobId(0),RollbackDetail.getHealthPlan(),DT1Entity)
					  DAOFunction.deleteTable("JOB_HISTORY",RollbackDetail.ProcessedDQ2JobId(0),RollbackDetail.getHealthPlan(),"NA")
					  DAOFunction.deleteTable("PROCESS_ENTITY_AUDIT",RollbackDetail.ProcessedDQ2JobId(0),RollbackDetail.getHealthPlan(),DT1Entity)
			}

		}
	}


}