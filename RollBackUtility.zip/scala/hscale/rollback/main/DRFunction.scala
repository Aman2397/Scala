package hscale.rollback.main
import org.apache.hadoop.fs.{ FileSystem, Path }
import hscale.rollback.ApplicationData._
class DRfunction(RollbackDetail:RollbackApplicationDetails) {

	def DRFunction(){

		for (counter <- 0 until RollbackDetail.AllProcessedDT2MappingId.length) {
			if (RollbackDetail.AllDependentDT2MappingId.contains(RollbackDetail.AllProcessedDT2MappingId(counter)) == true) {
				var DT2Entity = RollbackDetail.AllProcessedDT2EntityName(counter).toUpperCase
						var DT2ModelName = RollbackDetail.AllProcessedDT2ModelName(counter)
						var DREntity = DT2Entity

						val Index = RollbackDetail.ProcessedDRDomain.indexOf(DT2ModelName)
						val DRAppId = RollbackDetail.ProcessedDRJobId(Index)
						var DRPath = new Path(RollbackDetail.fileConf.getString("hscalePath.hscale_base_path")+RollbackDetail.fileConf.getString("hscalePath.dr")+DT2ModelName+"/"+DREntity+"/HSCALE_ORGANIZATION_CODE="+RollbackDetail.getHealthPlan())
						

						if(RollbackDetail.DREntities.contains(DREntity) == true){
							if ((DREntity.equalsIgnoreCase("MEMBERADDRESS"))||(DREntity.equalsIgnoreCase("MEMBERELIGIBILITY"))||(DREntity.equalsIgnoreCase("MEMBERCAREGAP")))

							
								HDFSDeleteFunction.DeleteDR(RollbackDetail.spark,RollbackDetail.fs,DRPath,new Path(RollbackDetail.fileConf.getString("backupPath.temp")),RollbackDetail.getBatchid().toInt,DREntity,"MemberSourceSystemUniqueId",RollbackDetail.CurrentAppId,RollbackDetail)


								else
									HDFSDeleteFunction.DeleteDR(RollbackDetail.spark,RollbackDetail.fs,DRPath,new Path(RollbackDetail.fileConf.getString("backupPath.temp")),RollbackDetail.getBatchid().toInt,DREntity,"BUSINESSKEY",RollbackDetail.CurrentAppId,RollbackDetail)
						    DAOFunction.deleteTable("DR_EXEC_STATUS",RollbackDetail.AllProcessedDT2JobId(counter),RollbackDetail.getHealthPlan(),DREntity)
						DAOFunction.deleteTable("DR_AUDIT_DETAILS",RollbackDetail.AllProcessedDT2JobId(counter),RollbackDetail.getHealthPlan(),DREntity)
						}}
		}    
	   

	}
}