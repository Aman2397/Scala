package hscale.rollback.main
import hscale.rollback.ApplicationData.RollbackApplicationDetails
import com.typesafe.config._
import hscale.rollback.ApplicationData.DAOFunction

class DAfunction(RollbackDetail:RollbackApplicationDetails){
 val dbConf = ConfigFactory.load("db.properties")
	def DAFunction(){
		if(RollbackDetail.DAEntities.length>0){
		for (counter <- 0 until RollbackDetail.DAEntities.length) {
			if (RollbackDetail.DependentEntities_DA.contains(RollbackDetail.DAEntities(counter)) == true) {
			
			DAOFunction.deleteTable("AGGREGATION_AUDIT",RollbackDetail.DA_JobId,RollbackDetail.getHealthPlan(),RollbackDetail.DAEntities(counter).toUpperCase());
			
			}
			}
		}
		
	}
}