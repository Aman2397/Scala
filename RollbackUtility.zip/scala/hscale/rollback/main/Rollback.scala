package hscale.rollback.main

import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.types._
import org.apache.spark.SparkContext._
import org.apache.log4j._
import com.typesafe.config._
import org.apache.hadoop.fs.{FileSystem, Path}
import hscale.rollback.ApplicationData
import hscale.rollback.ApplicationData._
import org.slf4j.LoggerFactory;
object Rollback {
   
  def main(args: Array[String]) {

   val LOGGER = LoggerFactory.getLogger("Rollback")
   
    LOGGER.info("Application Started");
 
    val HealthPlan = scala.io.StdIn.readLine();
    println("SOURCE ENTITY NAME:")
    val EntityName = scala.io.StdIn.readLine();
   val rd=new RollbackApplicationDetails(HealthPlan,EntityName)
    println("OBJECT CREATED")
    LOGGER.info(s"CurrentAppId ${rd.CurrentAppId}");
    val da=new DAfunction(rd)
    LOGGER.info("DA Rollback Started");
    da.DAFunction();
    LOGGER.info("DA Rollback Completed");
    val dq=new DQfunction(rd)
    LOGGER.info("DQ1 Rollback Started");
    dq.Dq1Function();
    LOGGER.info("DQ1 Rollback Completed");
    val dt=new DTfunction(rd); 
    LOGGER.info("DT1 Rollback Started");
    dt.dt1function();
    LOGGER.info("DT1 Rollback Completed");
    LOGGER.info("DQ2 Rollback Started");
    dq.Dq2Function()
    LOGGER.info("DQ2 Rollback Completed");
    LOGGER.info("DT2 Rollback Started");
    dt.dt2function() 
    LOGGER.info("DT2 Rollback Completed");
    val dr=new DRfunction(rd)
    LOGGER.info("DR Rollback Started");
    dr.DRFunction()
    LOGGER.info("DR Rollback Completed");
   
  
   
 

  
    
    
     println("END");
    
    
  
    
    test.show
    rd.showValue()
    val bi=rd.getBatchid()  
    val dp=rd.getdependenciesList()
    
     for (p <- 0 until dp.length) {
      println(dp(p))

    }
  
  println("End")
  
   // val dqfuct=new DQfunction(rd)
  
    //rd.MappingConfig.collect()
    //dqfuct.DqFunction()    
    //rd.AllDependentDT2MappingId
    /*
    control_info.toString()
    println(control_info.toString());

    println("Enter ORG");
    val User_OrgCode = readLine();
    println("Enter Entity");
    val User_Entity = readLine();*/

    */
    
  }
  

}

/*
 *Audit log needs to delete for DQ--
 * 
 *Delete record from table
 * 
 *DA table delete--Aggregation_Audit
 * 
 *Config
 * 
 *need to create sql table --which entity is getting rollback, when it is happending and filename, status 
 */
