package hscale.rollback.ApplicationData
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.{ SparkConf, SparkContext }
import com.typesafe.config._
import scala.collection.mutable.ListBuffer
import hscale.rollback.main
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{ FileSystem, Path }
import org.apache.spark.sql._

class RollbackApplicationDetails(HealthPlan: String, EntityName:String) {

	val spark = SparkSession.builder()
			.appName("Rollback")
			.getOrCreate()
			
			//load("application.properties")
			//applicationConf.
			println("")
			//println(applicationConf.getString("resourcesPath.dependency"))
			println("")
			val applicationConf = ConfigFactory.load("application.properties")
    
    val fileConf = ConfigFactory.load("file.properties") 
     val dependencyConf = ConfigFactory.load("dependency.properties") 
    val test=applicationConf.getString("modelname.sourcemodel").toString()
    println(s"test $test")

			//  val conf = new SparkConf().setAppName("RollBack")
			//  val sc=new SparkContext(conf)
			//  val CurrentAppId = sc.getConf.getAppId
			val CurrentAppId = spark.sparkContext.getConf.getAppId
			val control_info=DAOFunction.getCONTROL_INFO(spark)
			val PROCESSENTITYAUDIT=DAOFunction.getPROCESS_ENTITY_AUDIT(spark)
			val JOBHISTORY=DAOFunction.getJOB_HISTORY(spark)
			val MappingConfig=DAOFunction.getMAPPING_CONFIG(spark)
			val dtmappingAudit=DAOFunction.getDT_MAPPING_AUDIT(spark)
			val drAudit=DAOFunction.getDR_AUDIT_DETAILS(spark)
			control_info.createOrReplaceTempView("CONTROL_INFO")
			PROCESSENTITYAUDIT.createOrReplaceTempView("PROCESS_ENTITY_AUDIT")
			JOBHISTORY.createOrReplaceTempView("JOB_HISTORY")
			MappingConfig.createOrReplaceTempView("MAPPING_CONFIG")
			dtmappingAudit.createOrReplaceTempView("DT_MAPPING_AUDIT")
			drAudit.createOrReplaceTempView("DR_AUDIT_DETAILS")
			val BatchId=getBatchid()                      //Batch id of the given entity.
			val Entity_Info = spark.sql(s"select Entity_load_date as Entity_load_date,SOURCE_TABLE_NAME,TARGET_FOLDER_NAME from CONTROL_INFO where ORGANIZATION_CODE='$HealthPlan' and BATCH_ID='$BatchId'").collect
			println(s"Entity_Info.length ${Entity_Info.length}")
			val ProcessedEntities=getProcessedEntities().toList
			//  val ActualEntityLoadDate=getActualEntityLoadDate().toList   
			val ProcessedEntitiesPath=getProcessedEntitiesPath().toList      // interim path for same batch entity
			val DependentEntities=getdependenciesList().toList               //list if entity which is depended on each other
			val DependentEntities_DA=getdependenciesList_DA().toList 
			val fs = FileSystem.get(spark.sparkContext.hadoopConfiguration)
			val otherbatchid=getotherBatchId()                               //getting the next ran batchid if it is there
			val JobId=getJobid(BatchId)                                      //DQ1 Job Id
			val OtherJobId=getJobid(otherbatchid)                            //Dq1 jobid ofother batchid
			getProcessedJobHistory(BatchId,otherbatchid).createOrReplaceTempView("ProcessedJobHistory")                 //Job Application ID for each Stage                         
      val DA_JobId=getDAJobid(BatchId)
      val DAEntities = ListBuffer[String]()
      getList_DAEntities();
			val DoubleQuotes='"'
			val AllDependentDT1MappingId = ListBuffer[String]()
			val AllDependentDT2MappingId = ListBuffer[String]()
			val AllProcessedDT1MappingId = ListBuffer[String]()
			val AllProcessedDT2MappingId = ListBuffer[String]()
			val AllDependentDT1EntityName = ListBuffer[String]()
			val AllProcessedDT1ModelName = ListBuffer[String]()
			val AllDependentDT2EntityName = ListBuffer[String]()
			val AllProcessedDQ2ModelName = ListBuffer[String]()
			val AllProcessedDQ2EntityName = ListBuffer[String]()
			val AllProcessedDAEntityName = ListBuffer[String]()
			val AllProcessedDT1EntityName = ListBuffer[String]()
			val AllProcessedDT2EntityName = ListBuffer[String]()
			val AllProcessedDT2ModelName = ListBuffer[String]()    
			val AllProcessedDT1JobId = ListBuffer[String]()
			val AllProcessedDT2JobId = ListBuffer[String]()   
			val ProcessedDRJobId = ListBuffer[String]()
			val ProcessedDRDomain = ListBuffer[String]()
			val DREntities = ListBuffer[String]()
			val DRAppId = ListBuffer[String]()
			for (x <- 0 until DependentEntities.length) {
				var TargetEntity = spark.sql(s"select replace(MAPPING_ID,':','_') as MAPPING_ID,DESTINATION_TABLE_NAME,TARGET_MODEL_TYPE,TARGET_MODEL_NAME,ORGANIZATION_CODE from MAPPING_CONFIG where replace(SOURCE_TABLE_NAMES,'$DoubleQuotes','') like '%entityName:${DependentEntities(x)},%' and ORGANIZATION_CODE='$HealthPlan' AND IS_DELETED=0 AND SOURCE_MODEL_TYPE='SM'").collect
						for (y <- 0 until TargetEntity.length) {
							var Target_Entities = TargetEntity(y).toString().replace("[", "").replace("]", "").split(",")
									var Mapping_Id = Target_Entities(0);
							AllDependentDT1MappingId += Mapping_Id
									AllDependentDT1EntityName += Target_Entities(1).toString();
							var DT1_ModelType = Target_Entities(2);
							var DT1_ModelName = Target_Entities(3);
							var DT1_Entity = Target_Entities(1).toString();
							var Target2Entity = spark.sql(s"select replace(MAPPING_ID,':','_') as MAPPING_ID,DESTINATION_TABLE_NAME,TARGET_MODEL_NAME from MAPPING_CONFIG where upper(replace(SOURCE_TABLE_NAMES,'$DoubleQuotes','')) like '%ENTITYNAME:$DT1_Entity,%' AND SOURCE_MODEL_TYPE='$DT1_ModelType' AND (SOURCES LIKE '$DT1_ModelName,%' OR SOURCES = '$DT1_ModelName' OR SOURCES LIKE ',$DT1_ModelName' OR SOURCES LIKE '%,$DT1_ModelName,%')AND ORGANIZATION_CODE IS NULL AND IS_DELETED=0").collect
									for (z <- 0 until Target2Entity.length) {
										//          println("FROM Z LOOP")
										var Target2_Entities = Target2Entity(z).toString().replace("[", "").replace("]", "").split(",")
												var DT2Mapping_Id = Target2_Entities(0);
										AllDependentDT2MappingId += DT2Mapping_Id
												AllDependentDT2EntityName += Target2_Entities(1).toString();
										var DT2_Entity = Target2_Entities(1);
										var MODEL_NAME = Target2_Entities(2);
									}
						}
			}
	val ProcessedDT1JobId=getProcessedJobid(applicationConf.getString("modelname.dataTransformation"),applicationConf.getString("modelname.intermediate"))
			val ProcessedDQ2JobId=getProcessedJobid(applicationConf.getString("modelname.dataquality"),applicationConf.getString("modelname.intermediate"))
			val ProcessedDT2JobId=getProcessedJobid(applicationConf.getString("modelname.dataTransformation"),applicationConf.getString("modelname.enterpriseModel"))
      val ProcessedDQ1JobId=getProcessedJobid(applicationConf.getString("modelname.dataquality"),applicationConf.getString("modelname.sourcemodel"))
			for (counter <- 0 until ProcessedDT1JobId.length) {
				var pid = ProcessedDT1JobId(counter)
						var DT1_Data = spark.sql(s"select replace(MAPPING_ID,':','_') as MAPPING_ID,ENTITY_NAME,TARGET_MODEL_NAME,JOB_ID FROM DT_MAPPING_AUDIT where JOB_ID='$pid' and ORGANIZATION_CODE='$HealthPlan' AND EXTRACTED_RECORD_COUNT<>0").collect
						for (counter <- 0 until DT1_Data.length) {
							var DT1_Info = DT1_Data(counter).toString().replace("[", "").replace("]", "").split(",")
									AllProcessedDT1MappingId += DT1_Info(0).toString()
									AllProcessedDT1EntityName += DT1_Info(1).toString()

									AllProcessedDT1ModelName += DT1_Info(2).toString()
									AllProcessedDT1JobId+=DT1_Info(3).toString()

						}
			}
	
	for (counter <- 0 until ProcessedDQ2JobId.length) {
		var processid = ProcessedDQ2JobId(counter)
				var DQ2_Data = spark.sql(s"select ENTITY_NAME,SOURCE FROM PROCESS_ENTITY_AUDIT where JOB_ID='$processid' and ORGANIZATION_CODE='$HealthPlan' AND EXTRACTED_COUNT<>0").collect
				for (counter <- 0 until DQ2_Data.length) {
					var DQ2_Info = DQ2_Data(counter).toString().replace("[", "").replace("]", "").split(",")

							AllProcessedDQ2EntityName += DQ2_Info(0).toString()
							AllProcessedDQ2ModelName += DQ2_Info(1).toString()

				}
	}
	println(s"$AllProcessedDQ2EntityName")
	println(s"$AllProcessedDQ2ModelName")
	println(s"AllProcessedDT1MappingId $AllProcessedDT1MappingId") 
	for (counter <- 0 until ProcessedDT2JobId.length) {
		var pid = ProcessedDT2JobId(counter)
				var DT2_Data = spark.sql(s"select replace(MAPPING_ID,':','_') as MAPPING_ID,ENTITY_NAME,TARGET_MODEL_NAME FROM DT_MAPPING_AUDIT where JOB_ID='$pid' and ORGANIZATION_CODE='$HealthPlan' AND EXTRACTED_RECORD_COUNT<>0").collect
				for (counter <- 0 until DT2_Data.length) {
					var DT2_Info = DT2_Data(counter).toString().replace("[", "").replace("]", "").split(",")
							AllProcessedDT2MappingId += DT2_Info(0).toString()
							AllProcessedDT2EntityName += DT2_Info(1).toString()
							AllProcessedDT2ModelName += DT2_Info(2).toString()

				}
	}  
	println(s"AllProcessedDT2MappingId")
	println(s"AllDependentDT2MappingId")
	//DR

	val DR_JOBID = spark.sql("select JOB_ID,MODEL_NAME from ProcessedJobHistory where JOB_TYPE='DR'").distinct().collect

	for (counter <- 0 until DR_JOBID.length) {
		val temp = DR_JOBID(counter).toString().replace("[", "").replace("]", "").split(",")
				ProcessedDRJobId += temp(0)
				ProcessedDRDomain += temp(1)
				val DRAuditEntries = spark.sql(s"select ENTITY_NAME from DR_AUDIT_DETAILS WHERE JOB_ID='${temp(0)}' AND (INSERTED_COUNT<>0 OR UPDATED_COUNT<>0)").collect
				for (i <- 0 until DRAuditEntries.length) {
					DREntities+=DRAuditEntries(i).toString().replace("[", "").replace("]", "").toUpperCase()
				}

	}
	println(s"processed jobid is: $ProcessedDRJobId")
	println(s"ProcessedDRDomain is: $ProcessedDRDomain")








	def getProcessedJobid(JobType:String,ModelType:String):ListBuffer[String]={
			val JOBID = spark.sql(s"select JOB_ID from ProcessedJobHistory where JOB_TYPE='$JobType' and MODEL_TYPE='$ModelType'").collect
					val ProcessedJobId = ListBuffer[String]()
					for (counter <- 0 until JOBID.length) { 
						ProcessedJobId += JOBID(counter).toString().replace("[", "").replace("]", "") 
					}
			ProcessedJobId
	}

	def getProcessedJobHistory(BatchId:Int,otherbatchid:Int):DataFrame={
	  println("START of getProcessedJobHistory")
			var tempProcessedJobHistory:DataFrame=null
					if (BatchId == otherbatchid) { 
						tempProcessedJobHistory=spark.sql(s"select JOB_TYPE,MODEL_TYPE,JOB_ID,JOB_NAME,JOB_TYPE,MODEL_NAME from JOB_HISTORY where job_id>='$JobId' AND ORGANIZATION_CODE='$HealthPlan' AND JOB_TYPE IN('DQ','DT','DR') order by job_id")
					}
					else { 
						tempProcessedJobHistory=spark.sql(s"select JOB_TYPE,MODEL_TYPE,JOB_ID,JOB_NAME,JOB_TYPE,MODEL_NAME from JOB_HISTORY where job_id>='$JobId' AND job_id<'$OtherJobId' and ORGANIZATION_CODE='$HealthPlan' AND JOB_TYPE IN('DQ','DT','DR') order by job_id")
					}
			println("end of getProcessedJobHistory")
			tempProcessedJobHistory.show(100,false)
	tempProcessedJobHistory
	}
	def getJobid(Batch_Id:Int):String={

			val Job_Id = spark.sql(s"select distinct JOB_ID from PROCESS_ENTITY_AUDIT  where ORGANIZATION_CODE='$HealthPlan' and  batch_id=$Batch_Id and component='DQ_SM'").collect
			println(s"Job_Id $Job_Id")		
			val ActualJob_id = Job_Id(0).toString().replace("[", "").replace("]", "")
					println("from get job id")
					ActualJob_id
					
	}
	def getDAJobid(Batch_Id:Int):String={
    println("from getDAJobid")
			val Job_Id = spark.sql(s"select distinct JOB_ID from PROCESS_ENTITY_AUDIT  where ORGANIZATION_CODE='$HealthPlan' and  batch_id=$Batch_Id and component='DA_SM'").collect
			println(s"Job_Id $Job_Id")
			var ActualJob_id="NA";
			if(Job_Id.length>0){
			  ActualJob_id = Job_Id(0).toString().replace("[", "").replace("]", "")
			}				
			println(s"ActualJob_id:$ActualJob_id")
					ActualJob_id
					
	}

	def getotherBatchId():Int={

			val otherbatchid=spark.sql(s"select coalesce(min(BATCH_ID),$BatchId) as BATCH_ID from CONTROL_INFO where ORGANIZATION_CODE='$HealthPlan' and BATCH_ID>$BatchId").collect
					val otherbatchid1 = otherbatchid(0).toString().replace("[", "").replace("]", "")
					println(s"otherbatchid1  is $otherbatchid1")
		
					otherbatchid1.toInt
	}


	def getdependenciesList():ListBuffer[String]={
			spark.read.format("csv").option("header", "true").load(dependencyConf.getString("resourcesPath.dependency")).createOrReplaceTempView("dependencies")
			val No_Of_Sources = spark.sql(s"select RelatedEntities as RelatedEntities from dependencies where SourceEntity LIKE '$EntityName%'").collect
			val DependentEntities = ListBuffer[String]()
			DependentEntities += EntityName
			if (No_Of_Sources.length > 0) {
				var temp = No_Of_Sources(0).toString().replace("[", "").replace("]", "").split(",")
						for (i <- 0 until temp.length)
							DependentEntities += temp(i)
			}
			DependentEntities
	}
	def getdependenciesList_DA():ListBuffer[String]={
			spark.read.format("csv").option("header", "true").load(dependencyConf.getString("resourcesPath.dependency")).createOrReplaceTempView("dependencies")
			val No_Of_Sources = spark.sql(s"select RelatedEntities as RelatedEntities from dependencies where SourceEntity LIKE '$EntityName%'").collect
			val DependentEntities = ListBuffer[String]()
			DependentEntities += EntityName.toUpperCase();
			if (No_Of_Sources.length > 0) {
				var temp = No_Of_Sources(0).toString().replace("[", "").replace("]", "").split(",")
						for (i <- 0 until temp.length)
							DependentEntities += temp(i).toUpperCase();
			}
			DependentEntities
	}
	def getList_DAEntities()={
	   println("from getList_DAEntities")
			val Entities = spark.sql(s"select distinct ENTITY_NAME from PROCESS_ENTITY_AUDIT  where ORGANIZATION_CODE='$HealthPlan' and  batch_id=$BatchId and component='DA_SM' AND JOB_ID='$DA_JobId' ").collect
			if (Entities.length > 0) {
				var temp = Entities(0).toString().replace("[", "").replace("]", "").split(",")
						for (i <- 0 until temp.length)
							DAEntities += temp(i)
			}
	   println(s"DAEntities $DAEntities")
			
	}
	

	def getBatchid():Int={
      println("getBatchid")
      println(s"Health plan and entity name is $HealthPlan and $EntityName")
			control_info.createOrReplaceTempView("CONTROL_INFO")
			val Maxbatch=spark.sql(s"select max(BATCH_ID) as BATCH_ID from CONTROL_INFO where ORGANIZATION_CODE='$HealthPlan' and SOURCE_TABLE_NAME='$EntityName'").collect
			val batchid=Maxbatch(0).toString().replace("[", "").replace("]", "")
			println(s"batchid  is $batchid")
			batchid.toInt
			 
	}

	def getProcessedEntities():ListBuffer[String]={
			var ProcessedEntities = ListBuffer[String]();
		 println("from ProcessedEntities")
					for (p <- 0 until Entity_Info.length) {
						var Info = Entity_Info(p).toString().replace("[", "").replace("]", "").split(",")       
								ProcessedEntities += Info(1)

					}	
		 println("end ProcessedEntities")	
			ProcessedEntities
	}
	def getActualEntityLoadDate():ListBuffer[String]={
			var ActualEntityLoadDate = ListBuffer[String]()
					for (p <- 0 until Entity_Info.length) 
					{
						var Info = Entity_Info(p).toString().replace("[", "").replace("]", "").split(",")       
								ActualEntityLoadDate += Info(0)

					}
			ActualEntityLoadDate
	}
	def getProcessedEntitiesPath():ListBuffer[String]={
			var ProcessedEntitiesPath = ListBuffer[String]()
					for (p <- 0 until Entity_Info.length) 
					{
						var Info = Entity_Info(p).toString().replace("[", "").replace("]", "").split(",")       
								ProcessedEntitiesPath += Info(2)

					}
			ProcessedEntitiesPath
	}

	def showValue(){
		println(HealthPlan)
		println(EntityName)
	}


	def getApplicationID{
		spark.sparkContext.getConf.getAppId
		val conf = new SparkConf().setAppName("RollBack").set("spark.driver.allowMultipleContexts", "true")
		val sc=new SparkContext(conf)
		val CurrentAppId = sc.getConf.getAppId
	}

	def getHealthPlan():String ={HealthPlan}
	def getEntityName():String= {EntityName}
}