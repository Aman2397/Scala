package hscale.rollback.ApplicationData

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.{ DataFrame, SQLContext, SparkSession }
import org.apache.spark.sql.functions._
import com.typesafe.config._
import java.util.Properties;
import java.sql.DriverManager;
object DAOFunction {
    val dbConf = ConfigFactory.load("db.properties");
  val url=dbConf.getString("db.url")+dbConf.getString("db.database");
  val username=dbConf.getString("db.user");
  val password=dbConf.getString("db.password");
  val driver=dbConf.getString("db.driver");
  val database=dbConf.getString("db.database");

  def getCONTROL_INFO(spark:SparkSession):DataFrame={
    println(s"url $url")
    val CONTROL_INFO=spark.read.format("jdbc").option("url",url).option("driver",driver).option("dbtable", "CONTROL_INFO").option("user",username).option("password",password).load().toDF()
    return CONTROL_INFO;
  }
  
  def getPROCESS_ENTITY_AUDIT(spark:SparkSession):DataFrame={
     
      val PROCESS_ENTITY_AUDIT=spark.read.format("jdbc").option("url",url).option("driver",driver).option("dbtable", "PROCESS_ENTITY_AUDIT").option("user",username).option("password",password).load().toDF()
    return PROCESS_ENTITY_AUDIT;
  }
  
  
  def getJOB_HISTORY(spark:SparkSession):DataFrame={
 
     val JOB_HISTORY=spark.read.format("jdbc").option("url",url).option("driver",driver).option("dbtable", "JOB_HISTORY").option("user",username).option("password",password).load().toDF()
    return JOB_HISTORY;
  }
  
  def getMAPPING_CONFIG(spark:SparkSession):DataFrame={
    
     val MAPPING_CONFIG=spark.read.format("jdbc").option("url",url).option("driver",driver).option("dbtable", "MAPPING_CONFIG").option("user",username).option("password",password).load().toDF()
    return MAPPING_CONFIG;
  }
  
  def getDT_MAPPING_AUDIT(spark:SparkSession):DataFrame={
    
    val DT_MAPPING_AUDIT=spark.read.format("jdbc").option("url",url).option("driver",driver).option("dbtable", "DT_MAPPING_AUDIT").option("user",username).option("password",password).load().toDF()
    return DT_MAPPING_AUDIT;
  }
  
  def getDR_AUDIT_DETAILS(spark:SparkSession):DataFrame={
    
    val DR_AUDIT_DETAILS=spark.read.format("jdbc").option("url",url).option("driver",driver).option("dbtable", "DR_AUDIT_DETAILS").option("user",username).option("password",password).load().toDF()
    return DR_AUDIT_DETAILS;
  }
  def getJDBCConnection(spark:SparkSession) = {
    
    val connectionProperties = new Properties()
    connectionProperties.put("user",username)
    connectionProperties.put("password",password)
    connectionProperties

  }
   def deleteTable(tableName:String,jobId:String,organizationCode:String,entityName:String) = {   
     
    val con = DriverManager.getConnection(url,username,password)
    val query="DELETE FROM "+database+"."+tableName+" where JOB_ID='"+jobId+"' and ORGANIZATION_CODE='"+organizationCode+"' AND ENTITY_NAME='"+entityName+"'";
    println(s"query is: $query")
   // val preparedStmt = con.prepareStatement(query) 
    //preparedStmt.execute()
    //con.close()
  }
}